#include<iostream>
using namespace std;
class student
{
private:
    string address="";
    int roll;
public:
    string number="";
    student(string a,int r,string n)
    {
        cout<<"Total information!"<<endl;
        address=a;
        roll=r;
        number=n;
    }
    void showstudentinfo()
    {
        cout<<"address is :"<<address<<endl;
        cout<<"roll is :"<<roll<<endl;
        cout<<"number is :"<<number<<endl;

    }

};
int main()
{
    student s1("Natore",12,"017918407");
    s1.showstudentinfo();
    student s2("Dhaka",21,"017418707");
    s2.showstudentinfo();
    return 0;
}
