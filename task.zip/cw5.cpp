#include<iostream>
using namespace std;
class employee{

private:

    string name;
    int year;
    int salary;
    string address;

public:

    void setName(string n){
        name = n;
    }

    void setyear(int y){
        year = y;
    }

    void setsalary(int s){
        salary = s;
    }

    void setaddress(string a)
    {
        address=a;
    }

    string getName(){ return name;}
    int getyear(){ return year;}
    int getsalary(){ return salary;}
    string getaddress(){ return address;}

    void showemployeeInfo(){
        cout<<"Name :"<< name <<endl;
        cout<<"year of joining :"<<year <<endl;
        cout<<"salary :"<<salary <<endl;
        cout<<"address :"<<address <<endl;
    }
};

int main(){

    employee s1, s2,s3;
    s1.setName("Robert");
    s1.setyear(1994);
    s1.setsalary(50000);
    s1.setaddress("64C-WallsStreat");

    s1.showemployeeInfo();
    cout<<endl;

    s2.setName("Sam");
    s2.setyear(2000);
    s2.setsalary(60000);
    s2.setaddress("68D-WallsStreat");

    s2.showemployeeInfo();
    cout<<endl;

    s3.setName("John");
    s3.setyear(1999);
    s3.setsalary(650000);
    s3.setaddress("26B-WallsStreat");

    s3.showemployeeInfo();

    return 0;
}


