#include<iostream>
using namespace std;
class student
{
public:
    string name="";
    int id;
    student(string n,int i)
    {
        cout<<"Total information!"<<endl;
        name=n;
        id=i;

    }
    void showstudentinfo()
    {
        cout<<"Name is :"<<name<<endl;
        cout<<"Id is :"<<id<<endl;

    }

};
int main()
{
    student s1("John",2222);
    s1.showstudentinfo();
    return 0;
}

