#include<iostream>
using namespace std;
class Box
{
private:
    float length;
    float height;
public:
    float breadth;
    void setData(float x,float y,float z)
    {
        length=x;
        breadth=y;
        height=z;
    }
    void getData()
    {
        cout<<"volume of box is  :"<<length*breadth*height<<endl;
    }

};
int main()
{
    float x;
    float y;
    float z;
    Box b1;
    cout<<"Enter any length : ";
    cin>>x;
    cout<<"Enter any breadth : ";
    cin>>y;
    cout<<"Enter any height : ";
    cin>>z;
    cout<<endl;
    b1.setData(x,y,z);
    b1.getData();
    return 0;
}

