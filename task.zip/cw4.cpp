#include<iostream>
using namespace std;
class area
{
private:
    float length;
public:
    float breadth;
    void setData(float x,float y)
    {
        length=x;
        breadth=y;
    }
    void getData()
    {
        cout<<"Rectangle is  :"<<length*breadth<<endl;
    }

};
int main()
{
    float x;
    float y;
    area a1;
    cout<<"Enter any height :"<<endl;
    cin>>x;
    cout<<"Enter any breadth :"<<endl;
    cin>>y;
    a1.setData(x,y);
    a1.getData();
    return 0;
}

